package tursi.view.events;

import java.util.EventListener;

public interface ScrollModeListener extends EventListener {

  public void scrollModeChanged(ScrollModeEvent e);

}
