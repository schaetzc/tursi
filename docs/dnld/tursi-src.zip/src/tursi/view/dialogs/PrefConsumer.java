package tursi.view.dialogs;

public interface PrefConsumer {

  public void consumePrefChange();

}
