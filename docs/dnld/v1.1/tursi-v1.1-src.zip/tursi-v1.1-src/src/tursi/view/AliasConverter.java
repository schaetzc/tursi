package tursi.view;

public interface AliasConverter {
  
  public String convertToAlias(int move);

}
